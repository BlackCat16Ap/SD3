# Instruksi
Cara pemakaian sc ini menggunakan libs <b>[linepy](https://github.com/dhenza1415/SKPY3)</b>,
# Cara install
- VPS Ubuntu
1. pip install python3-pip<br>
2. pip3 install rsa<br>
3. pip3 install PyQRCode<br>
4. pip3 install requests<br>
5. and other required<br><br>

# Install melalui VPS ( VIRTUAL PRIVATE SERVER )

sudo apt-get install git<br>
git clone https://github.com/dhenza1415/SKPY3<br>
sudo apt-get python3-pip<br>
sude pip3 install rsa<br>
sudo pip3 install requests<br>
sudo pip3 install googletrans<br>
sudo pip3 install bs4<br>
sudo pip3 install requests<br>
sudo pip3 install rsa<br>
sudo pip3 install thrift<br>
sudo pip3 install bs4<br>
sudo pip3 install pytz<br>
sudo pip3 install humanfriendly<br>
sudo pip3 install gtts<br>
sudo pip3 install googletrans<br>
sudo pip3 install wikipedia<br>
sudo pip3 install youtube_dl<br>
sudo pip3 install ffmpy<br>
cd SKPY3<br>
python3 sk10pro.py<br><br>
# Catatan
1. Jika os selain ubuntu bisa kalian sesuaikan sendiri<br>
2. Untuk instal termux tinggal ganti sudo jadi pip3 atu hapus bagian sudo <br>
3. Moga bermaanfaat add ᴄʀᴇᴀᴛᴏʀ <b> [line.me/ti/p/~dhenz415]<br><br>
